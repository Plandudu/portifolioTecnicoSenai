package com.example.calculadorahoraminutosegun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    EditText inputHora;
    EditText inputHora1;
    EditText inputMin;
    EditText inputMin1;
    TextView sh;
    TextView sm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        inputHora = findViewById(R.id.inputHora);
        inputHora1 = findViewById(R.id.inputHora1);
        inputMin = findViewById(R.id.inputMin);
        inputMin1 = findViewById(R.id.inputMin1);
        sh = findViewById(R.id.shText);
        sm = findViewById(R.id.smText);
    }

    public void somar(View view){
        int hora = Integer.valueOf(inputHora.getText().toString()) + Integer.valueOf(inputHora1.getText().toString());
        int min = Integer.valueOf(inputMin.getText().toString()) + Integer.valueOf(inputMin1.getText().toString());

        while (min > 59){
            hora++;
            min -= 60;
        }

        sh.setText(String.valueOf(hora));
        sm.setText(String.valueOf(min));
    }

    public void subtracao(View view){
        int hora = Integer.valueOf(inputHora.getText().toString()) - Integer.valueOf(inputHora1.getText().toString());
        int min = Integer.valueOf(inputMin.getText().toString()) - Integer.valueOf(inputMin1.getText().toString());

        while (min < 0){
            hora--;
            min += 60;
        }

        sh.setText(String.valueOf(hora));
        sm.setText(String.valueOf(min));
    }

    public void reset(View view){
        sh.setText("SH");
        sm.setText("SM");
    }
}